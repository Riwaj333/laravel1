

-   Admin : email = admin@gmail.com, password = admin123 and Role: Admin
-   Teacher : email = teacher@gmail.com, password = teacher123 and Role: Teacher
-   Parent : email = parent@gmail.com, password = parent123 and Role: Parent
-   Student : email = student@gmail.com, password = student123 and Role: Student
