<div class="w-full block mt-8">
    <div class="flex flex-wrap sm:flex-no-wrap justify-between">
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 rounded">
            <h3 class="text-gray-700 uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($parents))); ?></span>
                <span class="leading-tight">Parents</span>
            </h3>
        </div>
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 mx-0 sm:mx-6 my-4 sm:my-0 rounded">
            <h3 class="text-gray-700 uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($teachers))); ?></span>
                <span class="leading-tight">Teachers</span>
            </h3>
        </div>
        <div class="w-full bg-gray-200 text-center border border-gray-300 px-8 py-6 rounded">
            <h3 class="text-gray-700 uppercase font-bold">
                <span class="text-4xl"><?php echo e(sprintf("%02d", count($students))); ?></span>
                <span class="leading-tight">Students</span>
            </h3>
        </div>
    </div>
</div><?php /**PATH C:\Users\Adones\Downloads\laravel-school-management-system-master\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>